export class UserModel{
  id: number;
  name: string;
  email: string;
  username: string;
  password: string;
  role: string;
}
