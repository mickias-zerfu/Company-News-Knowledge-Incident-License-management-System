

export class CategoryModel {
  id: number;
  name: string;
  icon:string;
}
