export class LoginModel {
  userName: any ;
  password: any;
}
