export interface ReportCard {
  bgcolor: string,
  icon: string,
  title: string,
  subtitle: string,
  link:string
}
