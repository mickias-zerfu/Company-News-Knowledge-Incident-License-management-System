export class VendorModel {
  vendorId:string;
  name:string;
}
