
  export class BlogModel {
    id:         number;
    title:      string;
    content:    string;
    image_url:  string;
    created_at: string;
    updated_at: string;
}
