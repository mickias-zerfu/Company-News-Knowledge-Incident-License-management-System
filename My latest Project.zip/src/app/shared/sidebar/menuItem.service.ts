import { Injectable, Inject } from "@angular/core";
import { HttpClient } from "@angular/common/http";
// import { MenuItemModel } from "src/app/models/admin/menuItemModel";
// import { CrudService } from "src/app/shared/crudService/crudService.service";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class MenuItemService  {
  constructor(
  ) {
  }
}
