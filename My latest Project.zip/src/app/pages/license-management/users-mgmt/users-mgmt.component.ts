import { Component } from '@angular/core';

@Component({
  selector: 'app-users-mgmt',
  templateUrl: './users-mgmt.component.html',
  styleUrls: ['./users-mgmt.component.css']
})
export class UsersMgmtComponent {

}
