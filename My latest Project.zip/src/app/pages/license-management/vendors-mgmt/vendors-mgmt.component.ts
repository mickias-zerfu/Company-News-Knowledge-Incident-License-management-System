import { Component } from '@angular/core';

@Component({
  selector: 'app-vendors-mgmt',
  templateUrl: './vendors-mgmt.component.html',
  styleUrls: ['./vendors-mgmt.component.css']
})
export class VendorsMgmtComponent {

}
