import { Component } from '@angular/core';

@Component({
  selector: 'app-license-management',
  templateUrl: './license-management.component.html',
  styleUrls: ['./license-management.component.css']
})
export class LicenseManagementComponent {

}
