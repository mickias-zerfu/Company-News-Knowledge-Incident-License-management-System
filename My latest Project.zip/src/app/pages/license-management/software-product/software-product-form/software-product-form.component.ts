import { Component } from '@angular/core';

@Component({
  selector: 'app-software-product-form',
  templateUrl: './software-product-form.component.html',
  styleUrls: ['./software-product-form.component.css']
})
export class SoftwareProductFormComponent {

}
