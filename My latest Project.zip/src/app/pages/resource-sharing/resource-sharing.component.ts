import { Component, OnInit } from '@angular/core';
import { Topcard } from '../dashboard/dashboard.component';

@Component({
  selector: 'app-resource-sharing',
  templateUrl: './resource-sharing.component.html',
  styleUrls: ['./resource-sharing.component.css']
})
export class ResourceSharingComponent {}
