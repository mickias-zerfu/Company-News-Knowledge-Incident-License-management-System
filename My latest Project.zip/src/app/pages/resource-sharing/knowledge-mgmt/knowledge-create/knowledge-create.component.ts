import { Component } from '@angular/core';

@Component({
  selector: 'app-knowledge-create',
  templateUrl: './knowledge-create.component.html',
  styleUrls: ['./knowledge-create.component.css']
})
export class KnowledgeCreateComponent {

}
