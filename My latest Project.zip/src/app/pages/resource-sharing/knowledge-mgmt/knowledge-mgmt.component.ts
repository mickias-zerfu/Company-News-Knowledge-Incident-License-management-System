import { Component } from '@angular/core';

@Component({
  selector: 'app-knowledge-mgmt',
  templateUrl: './knowledge-mgmt.component.html',
  styleUrls: ['./knowledge-mgmt.component.css']
})
export class KnowledgeMgmtComponent {

}
