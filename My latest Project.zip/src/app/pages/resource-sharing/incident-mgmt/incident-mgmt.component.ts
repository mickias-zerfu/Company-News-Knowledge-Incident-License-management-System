import { Component } from '@angular/core';

@Component({
  selector: 'app-incident-mgmt',
  templateUrl: './incident-mgmt.component.html',
  styleUrls: ['./incident-mgmt.component.css']
})
export class IncidentMgmtComponent {

}
