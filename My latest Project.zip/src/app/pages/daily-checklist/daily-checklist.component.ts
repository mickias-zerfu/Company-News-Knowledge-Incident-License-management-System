import { Component } from '@angular/core';

@Component({
  selector: 'app-daily-checklist',
  templateUrl: './daily-checklist.component.html',
  styleUrls: ['./daily-checklist.component.css']
})
export class DailyChecklistComponent {

}
